﻿namespace TaskBlazor.Pages
{
    public class EditStudentBase
    {
    }
}
