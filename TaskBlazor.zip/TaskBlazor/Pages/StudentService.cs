﻿using StudentManagement;
namespace TaskBlazor.Pages

{
    public static class StudentService
    {
        private static readonly List<Student> students = new()
        {
           new Student { Id = 1,FirstName="Rohan",LastName="Dhok",Gender="Male",DateOfBirth=new DateTime(2000,4,4),Age=34,Class="12th",Address="Wardha" },
               new Student { Id = 1,FirstName="Rahul",LastName="Guru",Gender="Male",DateOfBirth=new DateTime(1995,5,10),Age=25,Class="10th",Address="Wardha" }

        };
        public static Student[] GetStudents()
        {
            return students.ToArray();
        }


        public static void AddStudent(Student student)
        {
            student.Id=students.Max(student => student.Id)+1;
            students.Add(student);
        }
        public static Student GetStudent(int id)
        {
            return students.Find(Student => Student.Id == id);
        }
        public static void DeleteStudent(int id)
        {

        }
        public static void UpdateStudent(Student updateGame)
        {
            Student exitingGame=GetStudent(updateGame.Id);
        }
    }
}
